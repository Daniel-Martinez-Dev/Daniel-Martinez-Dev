﻿
namespace ED2021_II
{
    partial class FormularioClientesEdicion
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormularioClientesEdicion));
            this.label24 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.B_Editar = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.TB_Name = new System.Windows.Forms.TextBox();
            this.TB_Last_name = new System.Windows.Forms.TextBox();
            this.TB_City = new System.Windows.Forms.TextBox();
            this.TB_Address = new System.Windows.Forms.TextBox();
            this.TB_PC = new System.Windows.Forms.TextBox();
            this.TB_Country = new System.Windows.Forms.TextBox();
            this.TB_Card = new System.Windows.Forms.TextBox();
            this.TB_Occupation = new System.Windows.Forms.TextBox();
            this.TB_Children_Home = new System.Windows.Forms.TextBox();
            this.TB_Income = new System.Windows.Forms.TextBox();
            this.TB_Children = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.TB_State = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.LB_DOB = new System.Windows.Forms.Label();
            this.LB_Account = new System.Windows.Forms.Label();
            this.LB_ID = new System.Windows.Forms.Label();
            this.CB_Marital = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.LB_Gender = new System.Windows.Forms.Label();
            this.CB_HomeOwner = new System.Windows.Forms.ComboBox();
            this.LB_Oppening = new System.Windows.Forms.Label();
            this.BC_Education = new System.Windows.Forms.ComboBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label24.Location = new System.Drawing.Point(6, 387);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(129, 25);
            this.label24.TabIndex = 97;
            this.label24.Text = "DATE OF BIRH";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(6, 107);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(115, 25);
            this.label7.TabIndex = 88;
            this.label7.Text = "FIRST NAME";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label18.Location = new System.Drawing.Point(6, 67);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(178, 25);
            this.label18.TabIndex = 87;
            this.label18.Text = "ACCOUNT NUMBER";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label17.Location = new System.Drawing.Point(7, 347);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(96, 25);
            this.label17.TabIndex = 86;
            this.label17.Text = "COUNTRY";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label16.Location = new System.Drawing.Point(6, 309);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(130, 25);
            this.label16.TabIndex = 85;
            this.label16.Text = "POSTAL CODE";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label15.Location = new System.Drawing.Point(17, 30);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(155, 25);
            this.label15.TabIndex = 83;
            this.label15.Text = "MARITAL STATUS";
            // 
            // B_Editar
            // 
            this.B_Editar.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.B_Editar.Location = new System.Drawing.Point(378, 557);
            this.B_Editar.Name = "B_Editar";
            this.B_Editar.Size = new System.Drawing.Size(178, 39);
            this.B_Editar.TabIndex = 80;
            this.B_Editar.Text = "ENVIAR";
            this.B_Editar.UseVisualStyleBackColor = true;
            this.B_Editar.Click += new System.EventHandler(this.B_Editar_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(7, 227);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(50, 25);
            this.label9.TabIndex = 75;
            this.label9.Text = "CITY";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(6, 187);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(91, 25);
            this.label8.TabIndex = 74;
            this.label8.Text = "ADDRESS";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(6, 149);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(112, 25);
            this.label6.TabIndex = 73;
            this.label6.Text = "LAST NAME";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(313, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(249, 32);
            this.label2.TabIndex = 71;
            this.label2.Text = "EDICION DE CLIENTES";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(203, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(460, 40);
            this.label3.TabIndex = 70;
            this.label3.Text = "CONTROL DE BASE DE DATOS SQL";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(6, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 25);
            this.label1.TabIndex = 69;
            this.label1.Text = "ID";
            // 
            // TB_Name
            // 
            this.TB_Name.Location = new System.Drawing.Point(238, 107);
            this.TB_Name.Name = "TB_Name";
            this.TB_Name.Size = new System.Drawing.Size(163, 23);
            this.TB_Name.TabIndex = 99;
            this.TB_Name.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_Last_name
            // 
            this.TB_Last_name.Location = new System.Drawing.Point(238, 149);
            this.TB_Last_name.Name = "TB_Last_name";
            this.TB_Last_name.Size = new System.Drawing.Size(163, 23);
            this.TB_Last_name.TabIndex = 103;
            this.TB_Last_name.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_City
            // 
            this.TB_City.Location = new System.Drawing.Point(238, 227);
            this.TB_City.Name = "TB_City";
            this.TB_City.Size = new System.Drawing.Size(163, 23);
            this.TB_City.TabIndex = 102;
            this.TB_City.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_Address
            // 
            this.TB_Address.Location = new System.Drawing.Point(238, 187);
            this.TB_Address.Name = "TB_Address";
            this.TB_Address.Size = new System.Drawing.Size(163, 23);
            this.TB_Address.TabIndex = 101;
            this.TB_Address.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_PC
            // 
            this.TB_PC.Location = new System.Drawing.Point(238, 309);
            this.TB_PC.Name = "TB_PC";
            this.TB_PC.Size = new System.Drawing.Size(163, 23);
            this.TB_PC.TabIndex = 106;
            this.TB_PC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_Country
            // 
            this.TB_Country.Location = new System.Drawing.Point(238, 347);
            this.TB_Country.Name = "TB_Country";
            this.TB_Country.Size = new System.Drawing.Size(163, 23);
            this.TB_Country.TabIndex = 104;
            this.TB_Country.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_Card
            // 
            this.TB_Card.Location = new System.Drawing.Point(249, 309);
            this.TB_Card.Name = "TB_Card";
            this.TB_Card.Size = new System.Drawing.Size(163, 23);
            this.TB_Card.TabIndex = 126;
            this.TB_Card.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_Occupation
            // 
            this.TB_Occupation.Location = new System.Drawing.Point(249, 347);
            this.TB_Occupation.Name = "TB_Occupation";
            this.TB_Occupation.Size = new System.Drawing.Size(163, 23);
            this.TB_Occupation.TabIndex = 124;
            this.TB_Occupation.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_Children_Home
            // 
            this.TB_Children_Home.Location = new System.Drawing.Point(249, 192);
            this.TB_Children_Home.Name = "TB_Children_Home";
            this.TB_Children_Home.Size = new System.Drawing.Size(163, 23);
            this.TB_Children_Home.TabIndex = 123;
            this.TB_Children_Home.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_Income
            // 
            this.TB_Income.Location = new System.Drawing.Point(249, 72);
            this.TB_Income.Name = "TB_Income";
            this.TB_Income.Size = new System.Drawing.Size(163, 23);
            this.TB_Income.TabIndex = 120;
            this.TB_Income.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_Children
            // 
            this.TB_Children.Location = new System.Drawing.Point(249, 150);
            this.TB_Children.Name = "TB_Children";
            this.TB_Children.Size = new System.Drawing.Size(163, 23);
            this.TB_Children.TabIndex = 119;
            this.TB_Children.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(17, 387);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(133, 25);
            this.label4.TabIndex = 117;
            this.label4.Text = "HOMEOWNER";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(17, 150);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(156, 25);
            this.label5.TabIndex = 115;
            this.label5.Text = "TOTAL CHILDREN";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(17, 110);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(83, 25);
            this.label10.TabIndex = 114;
            this.label10.Text = "GENDER";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(18, 347);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(126, 25);
            this.label11.TabIndex = 113;
            this.label11.Text = "OCCUPATION";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(17, 309);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(141, 25);
            this.label12.TabIndex = 112;
            this.label12.Text = "MEMBER CARD";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label19.Location = new System.Drawing.Point(18, 270);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(153, 25);
            this.label19.TabIndex = 110;
            this.label19.Text = "OPPENING DATE";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label20.Location = new System.Drawing.Point(17, 230);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(114, 25);
            this.label20.TabIndex = 109;
            this.label20.Text = "EDUCATION";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label21.Location = new System.Drawing.Point(17, 192);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(184, 25);
            this.label21.TabIndex = 108;
            this.label21.Text = "CHILDREN AT HOME";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label22.Location = new System.Drawing.Point(17, 70);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(151, 25);
            this.label22.TabIndex = 107;
            this.label22.Text = "YEARLY INCOME";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.TB_State);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.LB_DOB);
            this.groupBox1.Controls.Add(this.LB_Account);
            this.groupBox1.Controls.Add(this.LB_ID);
            this.groupBox1.Controls.Add(this.TB_PC);
            this.groupBox1.Controls.Add(this.TB_Country);
            this.groupBox1.Controls.Add(this.TB_Last_name);
            this.groupBox1.Controls.Add(this.TB_City);
            this.groupBox1.Controls.Add(this.TB_Address);
            this.groupBox1.Controls.Add(this.TB_Name);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(16, 107);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(413, 429);
            this.groupBox1.TabIndex = 127;
            this.groupBox1.TabStop = false;
            // 
            // TB_State
            // 
            this.TB_State.Location = new System.Drawing.Point(238, 270);
            this.TB_State.Name = "TB_State";
            this.TB_State.Size = new System.Drawing.Size(163, 23);
            this.TB_State.TabIndex = 112;
            this.TB_State.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label13.Location = new System.Drawing.Point(7, 270);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(62, 25);
            this.label13.TabIndex = 111;
            this.label13.Text = "STATE";
            // 
            // LB_DOB
            // 
            this.LB_DOB.AutoSize = true;
            this.LB_DOB.BackColor = System.Drawing.SystemColors.ControlLight;
            this.LB_DOB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LB_DOB.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.LB_DOB.Location = new System.Drawing.Point(238, 387);
            this.LB_DOB.Name = "LB_DOB";
            this.LB_DOB.Size = new System.Drawing.Size(160, 27);
            this.LB_DOB.TabIndex = 110;
            this.LB_DOB.Text = "                   label4";
            // 
            // LB_Account
            // 
            this.LB_Account.AutoSize = true;
            this.LB_Account.BackColor = System.Drawing.SystemColors.ControlLight;
            this.LB_Account.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LB_Account.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.LB_Account.Location = new System.Drawing.Point(238, 67);
            this.LB_Account.Name = "LB_Account";
            this.LB_Account.Size = new System.Drawing.Size(160, 27);
            this.LB_Account.TabIndex = 109;
            this.LB_Account.Text = "                   label4";
            // 
            // LB_ID
            // 
            this.LB_ID.AutoSize = true;
            this.LB_ID.BackColor = System.Drawing.SystemColors.ControlLight;
            this.LB_ID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LB_ID.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.LB_ID.Location = new System.Drawing.Point(238, 27);
            this.LB_ID.Name = "LB_ID";
            this.LB_ID.Size = new System.Drawing.Size(160, 27);
            this.LB_ID.TabIndex = 107;
            this.LB_ID.Text = "                   label4";
            // 
            // CB_Marital
            // 
            this.CB_Marital.FormattingEnabled = true;
            this.CB_Marital.Location = new System.Drawing.Point(248, 32);
            this.CB_Marital.Name = "CB_Marital";
            this.CB_Marital.Size = new System.Drawing.Size(161, 23);
            this.CB_Marital.TabIndex = 108;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.LB_Gender);
            this.groupBox2.Controls.Add(this.CB_HomeOwner);
            this.groupBox2.Controls.Add(this.CB_Marital);
            this.groupBox2.Controls.Add(this.LB_Oppening);
            this.groupBox2.Controls.Add(this.BC_Education);
            this.groupBox2.Controls.Add(this.TB_Card);
            this.groupBox2.Controls.Add(this.TB_Occupation);
            this.groupBox2.Controls.Add(this.TB_Children_Home);
            this.groupBox2.Controls.Add(this.TB_Income);
            this.groupBox2.Controls.Add(this.TB_Children);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Location = new System.Drawing.Point(439, 107);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(432, 428);
            this.groupBox2.TabIndex = 128;
            this.groupBox2.TabStop = false;
            // 
            // LB_Gender
            // 
            this.LB_Gender.AutoSize = true;
            this.LB_Gender.BackColor = System.Drawing.SystemColors.ControlLight;
            this.LB_Gender.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LB_Gender.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.LB_Gender.Location = new System.Drawing.Point(249, 108);
            this.LB_Gender.Name = "LB_Gender";
            this.LB_Gender.Size = new System.Drawing.Size(160, 27);
            this.LB_Gender.TabIndex = 111;
            this.LB_Gender.Text = "                   label4";
            // 
            // CB_HomeOwner
            // 
            this.CB_HomeOwner.FormattingEnabled = true;
            this.CB_HomeOwner.Location = new System.Drawing.Point(250, 389);
            this.CB_HomeOwner.Name = "CB_HomeOwner";
            this.CB_HomeOwner.Size = new System.Drawing.Size(162, 23);
            this.CB_HomeOwner.TabIndex = 129;
            // 
            // LB_Oppening
            // 
            this.LB_Oppening.AutoSize = true;
            this.LB_Oppening.BackColor = System.Drawing.SystemColors.ControlLight;
            this.LB_Oppening.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LB_Oppening.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.LB_Oppening.Location = new System.Drawing.Point(249, 270);
            this.LB_Oppening.Name = "LB_Oppening";
            this.LB_Oppening.Size = new System.Drawing.Size(160, 27);
            this.LB_Oppening.TabIndex = 109;
            this.LB_Oppening.Text = "                   label4";
            // 
            // BC_Education
            // 
            this.BC_Education.FormattingEnabled = true;
            this.BC_Education.Location = new System.Drawing.Point(250, 230);
            this.BC_Education.Name = "BC_Education";
            this.BC_Education.Size = new System.Drawing.Size(162, 23);
            this.BC_Education.TabIndex = 128;
            // 
            // FormularioClientesEdicion
            // 
            this.ClientSize = new System.Drawing.Size(883, 619);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.B_Editar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormularioClientesEdicion";
            this.Text = "Control BD SQL";
            this.Load += new System.EventHandler(this.FormularioClientesEdicion_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }


        #endregion

        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button B_Editar;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TB_Name;
        private System.Windows.Forms.TextBox TB_Last_name;
        private System.Windows.Forms.TextBox TB_City;
        private System.Windows.Forms.TextBox TB_Address;
        private System.Windows.Forms.TextBox TB_PC;
        private System.Windows.Forms.TextBox TB_Country;
        private System.Windows.Forms.TextBox TB_Card;
        private System.Windows.Forms.TextBox TB_Occupation;
        private System.Windows.Forms.TextBox TB_Children_Home;
        private System.Windows.Forms.TextBox TB_Income;
        private System.Windows.Forms.TextBox TB_Children;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox CB_Marital;
        private System.Windows.Forms.Label LB_ID;
        private System.Windows.Forms.ComboBox CB_HomeOwner;
        private System.Windows.Forms.Label LB_Oppening;
        private System.Windows.Forms.ComboBox BC_Education;
        private System.Windows.Forms.Label LB_DOB;
        private System.Windows.Forms.Label LB_Account;
        private System.Windows.Forms.Label LB_Gender;
        private System.Windows.Forms.TextBox TB_State;
        private System.Windows.Forms.Label label13;
    }
}

