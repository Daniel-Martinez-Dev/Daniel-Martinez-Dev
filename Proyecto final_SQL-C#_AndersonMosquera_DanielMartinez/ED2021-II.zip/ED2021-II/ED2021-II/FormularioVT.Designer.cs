﻿
namespace ED2021_II
{
    partial class FormularioTiendas
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()

        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormularioTiendas));
            this.B_Editar = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.TB_G_SQFT = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.TB_SQFT = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.L_ID = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.TB_Remodel = new System.Windows.Forms.TextBox();
            this.L_opening = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.L_type = new System.Windows.Forms.Label();
            this.L_name = new System.Windows.Forms.Label();
            this.L_RegionId = new System.Windows.Forms.Label();
            this.L_city = new System.Windows.Forms.Label();
            this.L_country = new System.Windows.Forms.Label();
            this.L_State = new System.Windows.Forms.Label();
            this.L_Address = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.TB_Telephone = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // B_Editar
            // 
            this.B_Editar.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.B_Editar.Location = new System.Drawing.Point(158, 674);
            this.B_Editar.Name = "B_Editar";
            this.B_Editar.Size = new System.Drawing.Size(178, 39);
            this.B_Editar.TabIndex = 46;
            this.B_Editar.Text = "ENVIAR";
            this.B_Editar.UseVisualStyleBackColor = true;
            this.B_Editar.Click += new System.EventHandler(this.B_Editar_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(13, 627);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(142, 25);
            this.label11.TabIndex = 44;
            this.label11.Text = "GROCERY SQFT";
            // 
            // TB_G_SQFT
            // 
            this.TB_G_SQFT.Location = new System.Drawing.Point(259, 629);
            this.TB_G_SQFT.Name = "TB_G_SQFT";
            this.TB_G_SQFT.Size = new System.Drawing.Size(163, 23);
            this.TB_G_SQFT.TabIndex = 43;
            this.TB_G_SQFT.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(13, 587);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(112, 25);
            this.label10.TabIndex = 42;
            this.label10.Text = "TOTAL SQFT";
            // 
            // TB_SQFT
            // 
            this.TB_SQFT.Location = new System.Drawing.Point(259, 589);
            this.TB_SQFT.Name = "TB_SQFT";
            this.TB_SQFT.Size = new System.Drawing.Size(163, 23);
            this.TB_SQFT.TabIndex = 41;
            this.TB_SQFT.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(12, 299);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(216, 25);
            this.label8.TabIndex = 38;
            this.label8.Text = "STORE STREET ADDRESS";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(12, 260);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(124, 25);
            this.label6.TabIndex = 35;
            this.label6.Text = "STORE NAME";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // L_ID
            // 
            this.L_ID.AutoSize = true;
            this.L_ID.BackColor = System.Drawing.SystemColors.ControlLight;
            this.L_ID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.L_ID.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.L_ID.Location = new System.Drawing.Point(258, 135);
            this.L_ID.Name = "L_ID";
            this.L_ID.Size = new System.Drawing.Size(165, 27);
            this.L_ID.TabIndex = 32;
            this.L_ID.Text = "                    label4";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(111, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(242, 32);
            this.label2.TabIndex = 31;
            this.label2.Text = "EDICION DE TIENDAS";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(12, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(460, 40);
            this.label3.TabIndex = 30;
            this.label3.Text = "CONTROL DE BASE DE DATOS SQL";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(12, 135);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 25);
            this.label1.TabIndex = 28;
            this.label1.Text = "ID";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label13.Location = new System.Drawing.Point(13, 551);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(204, 25);
            this.label13.TabIndex = 48;
            this.label13.Text = "STORE REMODEL DATE";
            // 
            // TB_Remodel
            // 
            this.TB_Remodel.Location = new System.Drawing.Point(259, 551);
            this.TB_Remodel.Name = "TB_Remodel";
            this.TB_Remodel.Size = new System.Drawing.Size(163, 23);
            this.TB_Remodel.TabIndex = 47;
            this.TB_Remodel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // L_opening
            // 
            this.L_opening.AutoSize = true;
            this.L_opening.BackColor = System.Drawing.SystemColors.ControlLight;
            this.L_opening.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.L_opening.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.L_opening.Location = new System.Drawing.Point(259, 509);
            this.L_opening.Name = "L_opening";
            this.L_opening.Size = new System.Drawing.Size(165, 27);
            this.L_opening.TabIndex = 50;
            this.L_opening.Text = "                  label12";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label15.Location = new System.Drawing.Point(13, 509);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(215, 25);
            this.label15.TabIndex = 49;
            this.label15.Text = "STORE OPENNING DATE";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(12, 338);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(109, 25);
            this.label9.TabIndex = 40;
            this.label9.Text = "STORE CITY";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label16.Location = new System.Drawing.Point(12, 377);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(121, 25);
            this.label16.TabIndex = 51;
            this.label16.Text = "STORE STATE";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label17.Location = new System.Drawing.Point(12, 418);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(155, 25);
            this.label17.TabIndex = 52;
            this.label17.Text = "STORE COUNTRY";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label18.Location = new System.Drawing.Point(12, 175);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(102, 25);
            this.label18.TabIndex = 56;
            this.label18.Text = "REGION ID";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(12, 218);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(113, 25);
            this.label7.TabIndex = 58;
            this.label7.Text = "STORE TYPE";
            // 
            // L_type
            // 
            this.L_type.AutoSize = true;
            this.L_type.BackColor = System.Drawing.SystemColors.ControlLight;
            this.L_type.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.L_type.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.L_type.Location = new System.Drawing.Point(258, 218);
            this.L_type.Name = "L_type";
            this.L_type.Size = new System.Drawing.Size(165, 27);
            this.L_type.TabIndex = 60;
            this.L_type.Text = "                    label4";
            // 
            // L_name
            // 
            this.L_name.AutoSize = true;
            this.L_name.BackColor = System.Drawing.SystemColors.ControlLight;
            this.L_name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.L_name.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.L_name.Location = new System.Drawing.Point(258, 260);
            this.L_name.Name = "L_name";
            this.L_name.Size = new System.Drawing.Size(165, 27);
            this.L_name.TabIndex = 61;
            this.L_name.Text = "                    label4";
            // 
            // L_RegionId
            // 
            this.L_RegionId.AutoSize = true;
            this.L_RegionId.BackColor = System.Drawing.SystemColors.ControlLight;
            this.L_RegionId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.L_RegionId.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.L_RegionId.Location = new System.Drawing.Point(258, 175);
            this.L_RegionId.Name = "L_RegionId";
            this.L_RegionId.Size = new System.Drawing.Size(165, 27);
            this.L_RegionId.TabIndex = 62;
            this.L_RegionId.Text = "                    label4";
            // 
            // L_city
            // 
            this.L_city.AutoSize = true;
            this.L_city.BackColor = System.Drawing.SystemColors.ControlLight;
            this.L_city.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.L_city.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.L_city.Location = new System.Drawing.Point(258, 339);
            this.L_city.Name = "L_city";
            this.L_city.Size = new System.Drawing.Size(165, 27);
            this.L_city.TabIndex = 66;
            this.L_city.Text = "                    label4";
            // 
            // L_country
            // 
            this.L_country.AutoSize = true;
            this.L_country.BackColor = System.Drawing.SystemColors.ControlLight;
            this.L_country.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.L_country.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.L_country.Location = new System.Drawing.Point(258, 424);
            this.L_country.Name = "L_country";
            this.L_country.Size = new System.Drawing.Size(165, 27);
            this.L_country.TabIndex = 65;
            this.L_country.Text = "                    label4";
            // 
            // L_State
            // 
            this.L_State.AutoSize = true;
            this.L_State.BackColor = System.Drawing.SystemColors.ControlLight;
            this.L_State.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.L_State.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.L_State.Location = new System.Drawing.Point(258, 382);
            this.L_State.Name = "L_State";
            this.L_State.Size = new System.Drawing.Size(165, 27);
            this.L_State.TabIndex = 64;
            this.L_State.Text = "                    label4";
            // 
            // L_Address
            // 
            this.L_Address.AutoSize = true;
            this.L_Address.BackColor = System.Drawing.SystemColors.ControlLight;
            this.L_Address.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.L_Address.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.L_Address.Location = new System.Drawing.Point(258, 299);
            this.L_Address.Name = "L_Address";
            this.L_Address.Size = new System.Drawing.Size(165, 27);
            this.L_Address.TabIndex = 63;
            this.L_Address.Text = "                    label4";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label24.Location = new System.Drawing.Point(12, 465);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(133, 25);
            this.label24.TabIndex = 68;
            this.label24.Text = "STORE PHONE";
            // 
            // TB_Telephone
            // 
            this.TB_Telephone.Location = new System.Drawing.Point(258, 467);
            this.TB_Telephone.Name = "TB_Telephone";
            this.TB_Telephone.Size = new System.Drawing.Size(163, 23);
            this.TB_Telephone.TabIndex = 67;
            this.TB_Telephone.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // FormularioTiendas
            // 
            this.ClientSize = new System.Drawing.Size(485, 724);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.TB_Telephone);
            this.Controls.Add(this.L_city);
            this.Controls.Add(this.L_country);
            this.Controls.Add(this.L_State);
            this.Controls.Add(this.L_Address);
            this.Controls.Add(this.L_RegionId);
            this.Controls.Add(this.L_name);
            this.Controls.Add(this.L_type);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.L_opening);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.TB_Remodel);
            this.Controls.Add(this.B_Editar);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.TB_G_SQFT);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.TB_SQFT);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.L_ID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormularioTiendas";
            this.Text = "Control BD SQL";
            this.Load += new System.EventHandler(this.FormularioTiendas_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }


        #endregion

        private System.Windows.Forms.Button B_Editar;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox TB_G_SQFT;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox TB_SQFT;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label L_ID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox TB_Remodel;
        private System.Windows.Forms.Label L_opening;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label L_type;
        private System.Windows.Forms.Label L_name;
        private System.Windows.Forms.Label L_RegionId;
        private System.Windows.Forms.Label L_city;
        private System.Windows.Forms.Label L_country;
        private System.Windows.Forms.Label L_State;
        private System.Windows.Forms.Label L_Address;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox TB_Telephone;
    }
}

